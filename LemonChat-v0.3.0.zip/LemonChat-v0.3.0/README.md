## LemonChat 帮助文档

by @wangyizhi571247 and @Chingxu-Ying

### LemonChat 主界面指令集：

（空行）：直接进入 sender 和 receiver。

`changecolor`：更改 receiver 配色。

### Sender 指令集：

先输入 `:c>`。

`logout`：登出。

`exit`：退出 sender。

`quit`：退出 sender 和 receiver。

`reopen`：重新打开 sender 和 receiver。

`delete`：删除账户（可以用这个来改密码或用户名）。

其它的先鸽了。